import React from "react";

function Social() {
  return <div></div>;
}

export default Social;
