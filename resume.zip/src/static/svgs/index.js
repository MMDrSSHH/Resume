import HtmlLogo from "./Html5-logo.svg";
import CssLogo from "./Css3-logo.svg";
import TailwindLogo from "./Tailwind_CSS_Logo 1.svg";
import JavascriptLogo from "./Javascript_badge.svg";
import ReactLogo from "./React-icon.svg";
import NextLogo from "./Tabler-icons_brand-nextjs 1.svg";
import CSharpLogo from "./C-Sharp_Logo.svg";
import DotNetLogo from "./NET_Core_Logo.svg";
import GitLogo from "./Git_icon.svg";
import GitHubLogo from "./GitHub_Invertocat_Logo.svg";
import MSSqlServerLogo from "./Microsoft-sql-server-logo-svgrepo-com.svg";
import NodeJsLogo from "./Nodejs-logo.svg";
import ExpressJsLogo from "./Express-logo.svg";
import MongoDbLogo from "./MongoDb-logo.svg";
import DockerLogo from "./Docker-logo.svg"

export {
  HtmlLogo,
  CssLogo,
  TailwindLogo,
  JavascriptLogo,
  ReactLogo,
  NextLogo,
  CSharpLogo,
  DotNetLogo,
  GitLogo,
  GitHubLogo,
  MSSqlServerLogo,
  NodeJsLogo,
  ExpressJsLogo,
  MongoDbLogo,
  DockerLogo
};
