const i18nConfig = {
  locales: ["en", "fa"],
  defaultLocale: "en",
};

export default i18nConfig;
